#include "FrameBase.hpp"

FrameBase::FrameBase(std::string nickName){
    this->frameNickName = nickName;
}