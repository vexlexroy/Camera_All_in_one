#pragma once
#include "ConnectorBase.hpp"  // Include necessary headers
#include "ConnectorOut.hpp"
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>



template<typename T>
class ConnectorOut;
class ConnectorBase;

template<typename T>
class ConnectorIn: public ConnectorBase{
    public:
        std::thread thread;
        std::unique_ptr<T> newData = nullptr;

        ConnectorIn(int idConnector): ConnectorBase(idConnector){}
        virtual void threadLoop(){
            while(1){
                printf("Printing");
                std::this_thread::sleep_for(std::chrono::seconds(1));

            }
            /*
            //this->connectedFriend
            std::shared_ptr<ConnectorOut<T>> outFriend = std::dynamic_pointer_cast<ConnectorOut<T>>(this->connectedFriend);


            
            if(outFriend == nullptr){
                printf("ERRORRRR\n");
                return;
            }

            std::unique_lock<std::mutex> lock(outFriend->mutex);
            while(1){
                if(!this->isConnected()){
                    return;
                }
                
                if(outFriend == 0){
                    outFriend->condition.wait(lock);
                }

                if(!this->isConnected()){
                    return;
                }

                //there should be something in queue..., fetch and errase all other messages
                this->newData = outFriend->circularQueue.front();

                printf("Deleating %d elements from circBuffer\n", outFriend->circularQueue.size()-1);
                outFriend->circularQueue.clear();

                this->pParentNode->process(this->id);
            }
            */
        }

        void startConnectionThread(std::shared_ptr<ConnectorBase> connFriend){
            this->connectedFriend = connFriend;
            //this->thread = boost::thread(threadLoop, this);
        }
        

       void drawConnector() override{
            ImNodes::BeginInputAttribute(this->id);
            this->drawConnectorDescriptor();
            ImNodes::EndInputAttribute();
        }

        void printHello(){
            printf("Hello form connectorIn\n");
        }
        
};