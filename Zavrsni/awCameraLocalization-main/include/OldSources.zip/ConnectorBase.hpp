#pragma once
#include <string>
#include <memory>  // Include necessary headers
#include "NodeBase.hpp"

#include <imgui.h>

//class NodeBase;

// Forward declaration of NodeBase to avoid circular dependencies
class ConnectorBase{
    public:
        std::string connectorDataType;
        int id = 0;
        std::shared_ptr<NodeBase> pParentNode = nullptr;

        std::shared_ptr<ConnectorBase> connectedFriend = nullptr;

        ConnectorBase(int id){
            this->id = id;
        }

        bool isConnected(){
            return connectedFriend != nullptr;
        }

        virtual void drawConnectorDescriptor(){
            ImGui::Text(connectorDataType.c_str());
        }

        virtual void drawConnector()= 0;        
};