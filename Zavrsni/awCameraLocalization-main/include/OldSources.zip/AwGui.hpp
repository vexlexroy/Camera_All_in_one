#pragma once


#include "Mytemplate.hpp"

#include <iostream>
#include <imgui.h>
#include <imnodes.h>
#include "Class1.hpp"
#include "Class2.hpp"
#include "ConnectorIn.hpp"
#include "ConnectorOut.hpp"
#include "Class_1.hpp"
#include "Class_base.hpp"
#include <boost/version.hpp>
//#include "ElementFactory.hpp"  // Include necessary headers

class AwGui{

    private:
        int uniqueIdVal;
        //std::unordered_map<int, std::shared_ptr<NodeBase>> nodes;
        //std::unique_ptr<ElementFactory> factory;

    public:
        AwGui(){
            //factory = std::make_unique<ElementFactory>();
            //printf("Factory numm = %s\n", factory->listAvailableNodes("Bla")[0].c_str());
        }
        void process(){
            std::cout << "Hello World from Boost!" << std::endl;
            std::cout << "Boost version: " << BOOST_LIB_VERSION << std::endl;


            ConnectorIn<int> in(4);
            in.printHello();


            ConnectorOut<int> out(5, 6);
            out.printHello();

            out.addConnection(std::make_shared<ConnectorIn<int>>(in));
            

            Class_1<int> class1("Klasa1", 6);
            Class_2<int> class2("Klasa2", 8);

            class1.sharedPtr = std::make_shared<Class_2<int>>(class2);
            

            std::dynamic_pointer_cast<Class_2<int>>(class1.sharedPtr)->printSpecific();
            //ConnectorOut<int> conn(5, 6);
            //Create an instance of Class<int> with data 10
            Class1<int> c1(5);
            
            Class2<int> c2(4);
            
            c1.instanceOfClass2 = std::make_shared<Class2<int>>(c2);
            
            printf("%d, %d\n", c1.data, c1.instanceOfClass2->data);
            

            MyTemplate<int> intObj(42);

            // Create an instance of MyTemplate with double type
            MyTemplate<double> doubleObj(3.14);

            // Print the value of intObj twice using the global function
            intObj.printValueTwice(5);


            //prvo započni Imgui prozor...
            ImGui::Begin("AwGui");
            ImGui::Text("Ovo je AwGui!!");
            

            ImNodes::BeginNodeEditor();
            //Here i create new elements...

            bool canvasNewNode = ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows) && ImNodes::IsEditorHovered() && (ImGui::IsKeyReleased(ImGuiKey_A) || ImGui::IsMouseReleased(ImGuiMouseButton_Right));
            
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8.f, 8.f));
            if(!ImGui::IsAnyItemHovered() && canvasNewNode){
                ImGui::OpenPopup("add node");
            }

            if(ImGui::BeginPopup("add node")){
                ImGui::SeparatorText("Add node");
                ImGui::Selectable("Bla");

                const ImVec2 click_pos = ImGui::GetMousePosOnOpeningCurrentPopup();
                
                //std::vector<std::string> availableNodes = this->factory->listAvailableNodes();

                //for(int i = 0; i < availableNodes.size(); i++){
                //    if(ImGui::Selectable(availableNodes[i].c_str())){
                //        printf("Creating %s node\n", availableNodes[i].c_str());
                        //std::shared_ptr<NodeBase> newNode = this->factory->createNode(availableNodes[i]);
                        //NodeTest test(1);
                        //this->nodes[newNode->id] = newNode;
                        //printf("New Node added succesfully, id = %d!\n", test.id);
                //    }
                    
                //}
                
                ImGui::PopStyleVar();
            }
            //draw nodes...
            //for(auto i = nodes.begin(); i != nodes.end(); i++){
            //    i->second.draw();
            //}
            //draw links...
            //for(auto i = connectors.begin(); i != connectors.end(); i++){
            //    i->second.
            //}
            ImNodes::EndNodeEditor();

            
            ImGui::End();
        }
};