#pragma once

#include "ConnectorBase.hpp"  // Include necessary headers
#include <unordered_map>
#include <memory>
#include <ImNodes.h>  // Include necessary headers for ImNodes

class ConnectorBase;

class NodeBase{
    public:
        int id;
        std::unordered_map<int, std::shared_ptr<ConnectorBase>> connectors;

        NodeBase(int id): id(id){
            createStartingConnectors();
        }

        void drawNode(){
            ImNodes::BeginNode(this->id);
            
            //for example pictures etc...
            this->drawNodeContent();

            for(auto i = connectors.begin(); i != connectors.end(); i++){
                //i->second
                //i->second.get()->drawConnector();
            }
            ImNodes::EndNode();
        };
    
    protected:
        virtual void process(int connectorId) = 0;
        virtual void drawNodeContent() = 0;
        virtual void createStartingConnectors() = 0;
        virtual void connectorConnecting(int connId) = 0;
        virtual void connectorDisconnecting(int connId) = 0;
        //virtual void nodeHovered() = 0;  and that it works on mouse special button hold, that it is not intrusive, very cool...
        //virtual void connectorHovered(int connId) = 0; and that it works on mouse special button hold, that it is not intrusive, very cool...
        //virtual void linkHovered(int outConnIdOfLink) = 0;  and that it works on mouse special button hold, that it is not intrusive, very cool...
        //connector right click -> change connector circular buffer param for example, or change input logic fast...
        //delete node...
        
};
