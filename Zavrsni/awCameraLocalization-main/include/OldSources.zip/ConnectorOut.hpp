#pragma once

#include "ConnectorBase.hpp"
#include "ConnectorIn.hpp"  // Include necessary headers

#include <thread>
#include <mutex>
#include <condition_variable>
#include <memory>

template<typename T>
class ConnectorIn;
class ConnectorBase;

template<typename T>
class ConnectorOut: public ConnectorBase{
    public:
        //real communication syncronization variable instances are located here, and are created when creating object, and deleted when deleating object
        //InConnector only shares pointer to this class, where it has acces to all Messages in progress, condition variables and mutexes. All through one pointer...
        std::condition_variable condition;
        std::unique_ptr<T> dataInTransit;
        std::mutex mutex;
        
        int idLink = 0;

        ConnectorOut(int idConnector, int idLink): ConnectorBase(idConnector), idLink(idLink){}

        void addConnection(std::shared_ptr<ConnectorIn<T>> connectorInFriend){
            this->connectedFriend = connectorInFriend;
            //std::shared_ptr<ConnectorIn<T>> outFriend = std::dynamic_pointer_cast<ConnectorIn<T>>(this->connectedFriend);
            
            //connectorInFriend->startConnectionThread(std::make_shared<ConnectorOut<T>>(this));
        }

        
        void sendData(std::unique_ptr<T> message){
            //locks queue, puts new message in circularQueue, and trigers condition variable.
            std::unique_lock<std::mutex> lock(mutex);
            this->dataInTransit = nullptr;
            this->dataInTransit = message;
            this->condition.notify_one();
        }

        void drawConnection(){
            if(this->connectedFriend == nullptr){
                printf("Warning trying to draw connection whoose friend does not exist\n");
            } 
            ImNodes::Link(this->idLink, this->id, this->connectedFriend->id);
        }

        void drawConnector() override{
            ImNodes::BeginOutputAttribute(this->id);
            this->drawConnectorDescriptor();
            ImNodes::EndOutputAttribute();
        }

        void printHello(){
            printf("Hello form connectorOut\n");
        }
};

