#pragma once

#include "NodeBase.hpp"  // Include necessary headers
#include <cstdio>  // Include necessary headers for printf
#include <ImNodes.h>  // Include necessary headers for ImNodes

class NodeTest: public NodeBase{
    public:
        NodeTest(int id): NodeBase(id){}

        void drawNodeContent() override{
            ImGui::Text("Bla bla\n");
        }
        

        void createStartingConnectors() override{
            //What to do, add/remove connectors
            printf("Creating starting connectors\n");
        }
        void connectorConnecting(int connId) override{
            //What to do, add/remove connectors
            
        }
        void connectorDisconnecting(int connId) override{
            //What to do, add/remove connectors
            
        }
        
        void process(int connectorId) override{
            //Some data came on connector with connectorId
        }

};