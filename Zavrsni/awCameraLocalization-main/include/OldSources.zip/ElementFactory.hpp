#pragma once

#include <memory>
#include <string>
#include <vector>
#include "NodeBase.hpp"  // Include necessary headers
#include "NodeTest.hpp"

class ElementFactory{
    private:
        std::shared_ptr<int> gen;
    public:
        ElementFactory(){
            int generator = 0;
            gen = std::make_shared<int>(generator);
        }
        
        std::shared_ptr<NodeBase> createNode(std::string nodeName){
            if(nodeName == "Node_test"){
                *gen = *gen +1;

                return std::make_shared<NodeTest>(*gen);
            }
            return nullptr;
        }

        std::vector<std::string> listAvailableNodes(std::string connectorName){
            std::vector<std::string> availableNodes;
            availableNodes.push_back("Node_test");
            return availableNodes;
        }
        std::vector<std::string> listAvailableNodes(){
            std::vector<std::string> availableNodes;
            availableNodes.push_back("Node_test");
            return availableNodes;
        }

};